# سيف الله — نظام بناء تلقائي من ZIP

## اسم المشروع على GitHub
`SaifAllah-Khalid-Game`

## اسم الـWorkflow
`🎮 سيف الله - Build APK & AAB من ZIP`

## طريقة الاستخدام

1. أنشئ Repository باسم `SaifAllah-Khalid-Game`.
2. ارفع **ملف ZIP واحد** إلى الـRepository. الأفضل تسميته:
   `SaifAllahGame.zip`
3. يجب أن يحتوي الـZIP على مشروع اللعبة، ويكون بداخله `package.json` أو `index.html`.
4. بعد رفع الـZIP، افتح **Actions**.
5. شغّل Workflow:
   `🎮 سيف الله - Build APK & AAB من ZIP`
6. بعد انتهاء البناء افتح **Artifacts**.
7. حمّل:
   `SaifAllah-Android-Build`
8. ستجد داخله APK للتجربة وAAB للنشر.

## بعد أول إعداد
كل مرة تغيّر اللعبة، استبدل ملف `SaifAllahGame.zip` في المستودع واضغط Commit؛ الـWorkflow سيبدأ تلقائيًا بسبب تغيير ملف ZIP.

## مهم
GitHub لا يشغّل Workflow موجودًا **داخل ZIP**؛ ملف الـWorkflow نفسه يجب أن يكون في:
`.github/workflows/build-from-zip.yml`

لذلك في أول مرة فقط يجب رفع ملف الـWorkflow إلى GitHub. بعد ذلك يكفي رفع/استبدال ZIP اللعبة.
