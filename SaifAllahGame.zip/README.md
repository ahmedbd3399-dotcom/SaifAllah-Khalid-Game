# سيف الله — One ZIP Android Builder

## المطلوب منك
ارفع `SaifAllahGame.zip` إلى Repository، ومعه مجلد `.github/workflows`.

بعدها:
1. افتح **Actions**.
2. اختر **🎮 سيف الله - Auto Build APK + AAB**.
3. اضغط **Run workflow**.
4. انتظر حتى ينتهي.
5. افتح **Artifacts**.
6. نزّل `SaifAllah-Android-Build`.

ستجد:
- `SaifAllah-debug.apk` للتجربة على Android.
- `SaifAllah-release.aab` للنشر على Google Play إذا اكتمل إعداد التوقيع والإصدار.

## اسم Repository المقترح
`SaifAllah-Khalid-Game`

## ملاحظة
الـZIP الداخلي هو ملف اللعبة، والـWorkflow يحاول اكتشاف بنيته تلقائيًا ويجهز Capacitor/Android عند الحاجة.
